export interface Payload {
  sub: string;
}
