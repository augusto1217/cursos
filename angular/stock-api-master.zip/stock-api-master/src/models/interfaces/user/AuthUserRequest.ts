export interface AuthUserRequest {
  email: string;
  password: string;
}
