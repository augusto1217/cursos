export interface CreateProductRequest {
  name: string;
  price: string;
  description: string;
  category_id: string;
  amount: number;
}
